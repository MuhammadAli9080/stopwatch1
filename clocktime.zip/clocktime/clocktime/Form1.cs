﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clocktime
{
    public partial class Form1 : Form
    {
        int second;
        int minutes;
        int hourse;
        int microsecond;
        public Form1()
        {
            InitializeComponent();
            second = minutes = hourse = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            clock.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int width = this.Width;
            if (pictureBox1.Location.X > width - pictureBox1.Width)
            {
                pictureBox1.Location = new Point(1, pictureBox1.Location.Y);
            }
            else
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X + 100, pictureBox1.Location.Y);
            }
            microsecond++;
            if(microsecond>9)
            {
                second++;
                microsecond = 0;
            }
           
            if(second>59)
            {
                minutes++;
                second = 0;
            }
            if(minutes>59)
            {
                hourse++;
                minutes = 0;
            }
            lblhourse.Text = zero(hourse);
            lblminutes.Text = zero(minutes);
            lblsec.Text = zero(second);
            lblmicro.Text = zero(microsecond);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            second = minutes = hourse = 0; 
            lblhourse.Text = zero(hourse);
            lblminutes.Text = zero(minutes);
            lblsec.Text = zero(second);
            lblmicro.Text = zero(microsecond);
        }
        private string zero(double obj)
        {
            if(obj <=9)
            {
                return "0" + obj;
            }
            else
            {
                return obj.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

       
    }
}
